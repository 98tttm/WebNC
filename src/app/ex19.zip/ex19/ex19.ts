import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-ex19',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './ex19.html',
  styleUrls: ['./ex19.css'],
})
export class Ex19 {

}
