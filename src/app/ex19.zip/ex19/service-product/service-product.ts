import { Component } from '@angular/core';

@Component({
  selector: 'app-service-product',
  standalone: true,
  templateUrl: './service-product.html',
  styleUrls: ['./service-product.css'],
})
export class ServiceProduct {

}
