import { Component } from '@angular/core';

@Component({
  selector: 'app-ex13',
  standalone: true,
  templateUrl: './ex13.html',
  styleUrls: ['./ex13.css'],
})
export class Ex13 {

}
