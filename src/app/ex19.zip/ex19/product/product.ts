import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  standalone: true,
  templateUrl: './product.html',
  styleUrls: ['./product.css'],
})
export class Product {

}
