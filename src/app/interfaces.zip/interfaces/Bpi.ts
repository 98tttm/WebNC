export interface IBpi {
    code: string;
    symbol: string;
    rate: string;
    description: string;
    rate_float: number;
}
