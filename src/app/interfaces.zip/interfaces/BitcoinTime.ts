export interface IBitcoinTime {
    updated: string;
    updatedISO: string;
    updateduk: string;
}
