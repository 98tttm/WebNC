import { Component } from '@angular/core';

@Component({
  selector: 'app-list-product',
  standalone: true,
  templateUrl: './list-product.html',
  styleUrls: ['./list-product.css'],
})
export class ListProduct {

}
